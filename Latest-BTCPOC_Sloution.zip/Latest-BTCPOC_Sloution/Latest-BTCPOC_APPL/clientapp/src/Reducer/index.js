import { combineReducers } from "redux";
import { Rtemplate } from "./Rtemplate";
export const reducers = combineReducers({
    Rtemplate,
});
