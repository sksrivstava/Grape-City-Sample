import api from "./api";


export function getTemplate() {
  return (dispatch) => {
    api
      .dEmployee()
      .fetchall()
      .then((Response) => {
        dispatch({
          type: "GET_Template",
          payload: Response.data,
        });
      })
      .catch((err) => console.log(err));
  };
}

/* export function addEmployee(data) {
  return (dispatch) => {
    return dispatch({
      type: "ADD_EMPLOYEE",
      payload: data,
    });
  };
} */
export const addTemplate = (data, onSuccess) => (dispatch) => {
  // data = formatData(data);
  api
    .dEmployee()
    .create(data)
    .then((Response) => {
      dispatch({
        type: "ADD_Template",
        actplay: Response.data,
      });
      onSuccess();
    })
    .catch((err) => console.log(err));
};

/* export function editEmployee(data) {
  return (dispatch) => {
    return dispatch({
      type: "EDIT_EMPLOYEE",
      payload: data,
    });
  };
} */
export const editTemplate = (EmpId, data, onSuccess) => (dispatch) => {
  //data = formatData(data);
  window.alert(EmpId);

  api
    .dEmployee()
    .update(data)
    .then((Response) => {
      dispatch({
        type: "EDIT_Template",
        payload: { ...data },
      });
      onSuccess();
    })
    .catch((err) => console.log(err));
};

/* export function deleteEmployee(employeeId) {
  return (dispatch) => {
    return dispatch({
      type: "DELETE_EMPLOYEE",
      payload: employeeId,
    });
  };
}
 */

export const deleteTemplate = (EmpId, onSuccess) => (dispatch) => {
  window.alert(EmpId);
  api

    .dEmployee()
    .delete(EmpId)
    .then((Response) => {
      dispatch({
        type: "DELETE_Template",
        actplay: EmpId,
      });
      onSuccess();
    })
    .catch((err) => console.log(err));
};
