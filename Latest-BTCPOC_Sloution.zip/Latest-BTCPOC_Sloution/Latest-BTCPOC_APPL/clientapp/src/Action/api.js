import axios from "axios";

const baseurl = "http://localhost:62271/api/";
export default {
    Dtemplate(url = baseurl) {
        return {

            fetchall: () => axios.get(url + "ExlData/"),
            fetchByid: (id) => axios.get(url + "ExlData/" + id),
            update: (id, updateRecord) => axios.put(url + "ExlData", updateRecord),
            delete: (id) => axios.delete(url + "ExlData/" + id)

        }
}
}
