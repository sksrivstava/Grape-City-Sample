﻿import api from "./api";

export const ACTION_TYPES = {
    LIST: "LIST",
    UPDATE: "UPDATE",
    OPEN: "OPEN",
    DELETE:"DELETE"
}

export const fetchall = () => dispatch => {
    api.Dtemplate()
        .then(Response => {
            dispatch({
                type: ACTION_TYPES.fetchall,
                paylod: Response.data

            })
        })
            .catch(err=> console.log(err))
    }
    
  