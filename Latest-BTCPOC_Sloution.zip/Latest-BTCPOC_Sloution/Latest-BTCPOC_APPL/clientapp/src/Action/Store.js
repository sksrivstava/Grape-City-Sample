import { reducers } from "../Reducer/index";

import { applyMiddleware, combineReducers, compose, createStore } from 'redux';
import thunk from 'redux-thunk';
import { connectRouter, routerMiddleware } from 'connected-react-router';
import { History } from 'history';




export const Store = createStore(
    reducers,
  compose(
    applyMiddleware(thunk)
    //  window._REDUX_DEVTOOLS_EXTENSION_ && Window._REDUX_DEVTOOLS_EXTENSION_()
  )
);