﻿import React from "react";
import * as ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { ConnectedRouter } from 'connected-react-router';
import { createBrowserHistory } from 'history';
import { Store } from "./Action/Store";

const Templateform = (prpos) => {
    return (<div></div>)
}
export default Templateform;