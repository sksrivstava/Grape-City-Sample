//for upload
const express= require('express')
const efu = require('express-fileupload')
const app=express();
app.use(efu());
//upload block end

//for download
const http= require('http');
const fs = require('fs')
//end download block

const replace = require('replace-in-file');  //replace existing file

const fURL = "D:/sheet/"

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  });

app.get('/',(req,res,next)=>{
    res.status(200).send("Hello World");
})

app.post("/api/upload",function(req,res,next){
    const file =  req.files.xlfile; //req.files.<any name which would be the receiving key like File=abc.xlsx>
    file.mv("upload/"+file.name,function(err,result){
        if(err)
            throw err;
        res.send({
            success:true,
            message:"File uploaded"
        }); 
    });
})

app.post("/api/save",function(req,res,next){
    const file =  req.files.xlfile; //req.files.<any name which would be the receiving key like File=abc.xlsx>
    file.mv(fURL+file.name,function(err,result){
        if(err)
            throw err;
        res.send({
            success:true,
            message:"File uploaded"
        }); 
    });
})

app.get('/api/open/:fileName',function(req,res){
    fs.readFile(fURL+ req.params.fileName,function(err,content){
        if(!err){
        res.writeHead(200,{'Content-type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','Content-disposition' : `attachment;filename:${req.params.fileName}`})  
        res.end(content);
        }
    })
})


app.post("/api/replace",function(req,res,next){
    console.warn("replace code go here");
})

app.listen(3000,()=>{
    console.log('Started port:3000');
})