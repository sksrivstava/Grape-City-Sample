# Ref. link
https://www.npmjs.com/package/replace-in-file
https://nodejs.org/api/fs.html


# Packages
npm i express --save
npm i express-fileupload --save
npm i replace-in-file --save



to setup excel upload folder look for [const fURL = "E:/MyWork/"] and replace it with your folder where you want to save your files
 
currently </api/upload> </api/save> and </api/open> are working 

but use </api/save> and </api/open> to upload and download excel

# to install dependencies
npm install 

# to run api
node index.js


