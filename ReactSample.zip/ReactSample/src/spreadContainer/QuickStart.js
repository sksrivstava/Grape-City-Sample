import React, {Component} from 'react';
import {SpreadSheets, Worksheet, Column} from '@grapecity/spread-sheets-react';
import './Style.css'
import dataService from '../dataService'
import saveAs from 'file-saver';
import spreadExcel from '@grapecity/spread-excelio';

class QuickStart extends Component {

    constructor(props) {
        super(props);
        this.spreadBackColor = 'aliceblue';
        this.sheetName = 'Person Address';
        this.hostStyle = {
            top: '240px',
            bottom: '10px'
        };
        this.autoGenerateColumns = false;
        this.data = dataService.getPersonAddressData();
    }
    workbookInit = (spread) => {
        this.setState({
            spread: spread
        });
    }
    importFile = () => {
        var excelFile = document.getElementById("fileDemo").files[0];

        // Get an instance of IO class
        let excelIO = new spreadExcel.IO();
        excelIO.open(excelFile, (json) => {
            this.state.spread.fromJSON(json);
        }, (e) => {
            console.log(e);
        });
    }
    exportFile = () => {

        // Get an instance of IO class
        let excelIO = new spreadExcel.IO();
        let fileName = document.getElementById("exportFileName").value;
        if (fileName.substr(-5, 5) !== '.xlsx') {
            fileName += '.xlsx';
        }
        var json = JSON.stringify(this.state.spread.toJSON());
        excelIO.save(json, (blob) => {
            saveAs(blob, fileName);
        }, (e) => {
            console.log(e);
        });

    }
    render() {
        return (
            <div className="componentContainer" style={this.props.style}>
                <h3>Quick Start</h3>
                <div>
                    Steps for getting started with the SpreadJS in React applications:
                    <div>
                        <p>1. Add reference files in your React application.</p>
                        <p>2. Add a component to provide data and logic.</p>
                        <p>3. Bind data and some other options of spread.</p>
                        <p>4. Add some css to customize appearance.</p>
                    </div>
                </div>
                <div className="spreadContainer" style={this.hostStyle}>
                <input type="file" name="files[]" id="fileDemo" accept=".xlsx,.xls" />
                <input type="button" id="loadExcel" value="Import" onClick={this.importFile} />
                <input type="button" id="saveExcel" value="Export" onClick={this.exportFile} />
                <input type="text" id="exportFileName" placeholder="Export file name" value="export.xlsx" />
                <SpreadSheets backColor={this.spreadBackColor} hostStyle={this.hostStyle} workbookInitialized={this.workbookInit}>
                    <Worksheet>
                    </Worksheet>
                </SpreadSheets>

                
                </div>
            </div>

        )
    }
}

export default QuickStart