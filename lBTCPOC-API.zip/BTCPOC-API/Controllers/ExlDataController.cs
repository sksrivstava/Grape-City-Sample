﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BTCPOC_API.Module;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using System.IO;
using Newtonsoft.Json;
using System.Collections;
using BTCPOC_API.viewModel;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;

namespace BTCPOC_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExlDataController : ControllerBase
    {
        private readonly IDataProtector _protector;
        private readonly IRepoDataAccess ERepository;
        public ExlDataController(IRepoDataAccess _ERepository,  IDataProtectionProvider provider)
        {
            ERepository = _ERepository;
            _protector = provider.CreateProtector("BTCPOC_API.ExlDataController");
        }


     
        [HttpGet("{id}")]
        public void Getexcel(int id)
        {
           
            ExcelDataObj model = new ExcelDataObj();
            var dtaobj = ERepository.GetExceldata(id);  //Calling sp using EF Core
                                                        // var dtaobj = ERepository.GetDataById(1);  //Using ado.net 
            string errmsg = "";
            string base64data = string.Empty;
            if (dtaobj.excel != null)
            {

                try
                {
                    //  base64data = dtaobj.excel;
                    base64data = _protector.Unprotect(dtaobj.excel);
                byte[] bytes;
                // Credit: oybek https://stackoverflow.com/users/794764/oybek
                if (string.IsNullOrEmpty(base64data) || base64data.Length % 4 != 0
                   || base64data.Contains(" ") || base64data.Contains("\t") || base64data.Contains("\r") || base64data.Contains("\n"))
                {
                    errmsg = "Invalid Format";
                }
                
                     bytes = Convert.FromBase64String(base64data);
                

              
                //////

                /////
                string fileName = dtaobj.excelName;
                var response = new FileContentResult(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                response.FileDownloadName = fileName;

                Response.Clear();
                Response.Headers.Add("content-disposition", "attachment; filename=" + fileName);
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.Body.WriteAsync(bytes);

                }
                catch (Exception exception)
                {
                    errmsg = "Invalid Format";
                    // Handle the exception
                }
                // Response.OutputStream.Write(bytes, 0, bytes.Length);
                //  Response.StatusCode = StatusCodes.Status200OK;

                // Response.End();

            }
            //  return base64data;
        }
        [HttpGet]
        public  IEnumerable<Reportlist> Getexcel()
        {
            List<Reportlist> Modellst = new List<Reportlist>();
            Modellst =  ERepository.GetReportList();
             return Modellst;
        }


            [HttpPost]
        public string Post(ExcelDataObj values) //, bool includeAddress = false
        {
            ExcelDataObj model = new ExcelDataObj();

            values.excel = _protector.Protect(values.excel);


            //  var valuesDict = JsonConvert.DeserializeObject<IDictionary>(values);
            //   model = PopulateModel(model, valuesDict);

            string status = "";
            //Int32 rslt = ERepository.UpdateExcelData(values);
            status = ERepository.UpdateData(values);
                
         
            return status;
        }

    }
}
