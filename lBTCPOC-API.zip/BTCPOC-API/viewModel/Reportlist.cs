﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BTCPOC_API.viewModel
{
    public class Reportlist
    {
        public int id { get; set; }
        public string excelName { get; set; }
    }
}
