﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace BTCPOC_API.Module
{
    public interface IRepoDataAccess
    {
    //    Task<List<ExcelDataObj>> GetExceldata();

        Int32 UpdateExcelData(ExcelDataObj Exldat);
        ExcelDataObj GetExceldata(int id);

        List<ExcelDataObj> GetReportList();
        ExcelDataObj GetDataById(Int32 id);
        string UpdateData(ExcelDataObj Exldat);
    }

}
