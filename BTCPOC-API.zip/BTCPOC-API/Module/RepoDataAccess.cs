﻿
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;


namespace BTCPOC_API.Module
{
    public class RepoDataAccess  : IRepoDataAccess
    {
        //Server=HOMEPC\\SQLEXPRESS; Database=BTC-POCDB; uid=sa; password=sanjeev123; MultipleActiveResultSets=true
        public static string sqlDataSource = "Server=DESKTOP-O098VRN\\SQLEXPRESS; Database=BTC-POCDB; uid=sa; password=sanjeev123; MultipleActiveResultSets=true;";

       // public static string sqlDataSource = "Server=DESKTOP-O098VRN\\SQLEXPRESS; Database=BTC-POCDB; Trusted_Connection=True; MultipleActiveResultSets=true;";
        DataAccess db;
        public RepoDataAccess(DataAccess _db)
        {
            db = _db;
        }

        public ExcelDataObj GetDataById(Int32 id)
        {

            ExcelDataObj obj = new ExcelDataObj();
            try
            {
                SqlDataReader myReader;

                using (SqlConnection myCon = new SqlConnection(sqlDataSource))
                {
                    myCon.Open();
                    SqlCommand myCommand = new SqlCommand();
                       myCommand.CommandText = "usp_GetExcelData";
                    myCommand.Connection = myCon;
                    myCommand.CommandType = CommandType.StoredProcedure;
                    myCommand.Parameters.AddWithValue("@id", id);
                    myReader = myCommand.ExecuteReader();

                    if (myReader.HasRows)
                    {
                        while (myReader.Read())
                        {
                            obj.id = Convert.ToInt32( myReader["id"]);
                            obj.excelName = Convert.ToString(myReader["excelName"]);
                            obj.excel = Convert.ToString(myReader["excel"]);
                        }
                    }
                        myReader.Close();
                        myCon.Close();
 }                                   
            }
            catch (Exception ex)
            {
            }
            return obj;
        }
        public string UpdateData(ExcelDataObj Exldat)
        {
             string status = "";
            try
            {
                using (SqlConnection myCon = new SqlConnection(sqlDataSource))
                {
                    myCon.Open();
                    SqlCommand myCommand = new SqlCommand();
                    myCommand.CommandText = "usp_uploadExcel";
                    myCommand.Connection = myCon;
                    myCommand.CommandType = CommandType.StoredProcedure;
                    myCommand.Parameters.AddWithValue("@excelName", Exldat.excelName);
                    myCommand.Parameters.AddWithValue("@excel", Exldat.excel);
                    myCommand.Parameters.Add(new SqlParameter("@status", 0)).Direction = ParameterDirection.Output;
                    myCommand.ExecuteNonQuery();
                    if (Convert.ToInt32(myCommand.Parameters["@status"].Value) == 1)
                    {
                        status = "{result:200,msg:'saved'}";
                    }
                    else
                    {
                        status = "{result:500,msg:'unable to save'}";
                    }
                    myCon.Close();
                }
            }
            catch (Exception e)
            {
                status = "{result:501,msg:'" + e.Message + "'}";
            }
            return status;

        }
        public ExcelDataObj GetExceldata(int id)
        {
           
            
            
            //context.Database.ExecuteSqlRawAsync
            var IdParam = new SqlParameter("@id", id);
            ExcelDataObj exlobj = new ExcelDataObj();
            exlobj =  db.ExcelDataContext.FromSqlRaw("usp_GetExcelData @id" , IdParam).ToList()
                .FirstOrDefault();
            return exlobj;

            //var emailAddressParam = new SqlParameter("@emailAddress", id.EmailAddress);
            //var passwordParam = new SqlParameter("@passwordHash", id.PasswordHash);

            //var users = context
            //            .UserProfiles
            //            .FromSqlRaw("exec sp_GetUsers @emailAddress, @passwordHash", emailAddressParam, passwordParam)
            //            .ToList();

        }

        public Int32 UpdateExcelData(ExcelDataObj Exldat)
        {
            Int32 out1=0;
             //   out1= "";
          //  ExcelDataObj exlobj = new ExcelDataObj();
            var excelNamePrm = new SqlParameter("@excelName", Exldat.excelName);
            var excelPrm = new SqlParameter("@excel", Exldat.excel);
            var opt = new SqlParameter("@opt", 0);
           
          var  outl =  db.ExcelDataContext.FromSqlRaw(
                "usp_uploadReportData @excelName,@excel,@opt", excelNamePrm, excelPrm, opt);
            return out1;
        }

        public List<ExcelDataObj> GetReportList()
        {
            var IdParam = new SqlParameter("@id", "0");
           List<ExcelDataObj> exlobj = new List<ExcelDataObj>();
            exlobj = db.ExcelDataContext.FromSqlRaw("usp_GetExcelData @id", IdParam).ToList();
            return exlobj;

        }
    }

        //public ExcelDataObj GetExceldata(int id)
        //{
        //    throw new NotImplementedException();
        //}

        //public string UpdateData(ExcelDataObj Exldat)
        //{
        //    throw new NotImplementedException();
        //}

        //public int UpdateExcelData(ExcelDataObj Exldat)
        //{
        //    throw new NotImplementedException();
        //}
    }
