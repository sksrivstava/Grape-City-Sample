﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace BTCPOC_API.Module
{
    public class DataAccess: DbContext
    {
        public DataAccess(DbContextOptions<DataAccess> options): base(options)
        {

        }
        public DbSet<ExcelDataObj> ExcelDataContext { get; set; }

    }
}
