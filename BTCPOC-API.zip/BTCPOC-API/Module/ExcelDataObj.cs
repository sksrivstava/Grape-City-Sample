﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace BTCPOC_API.Module
{
    public class ExcelDataObj
    {
        [Key]
        public int id { get; set; }
        public string excelName { get; set; }
        public string excel { get; set; }
          }
}
