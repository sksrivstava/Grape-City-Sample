﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BTCPOC_API.Module;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using System.IO;
using Newtonsoft.Json;
using System.Collections;

namespace BTCPOC_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExlDataController : ControllerBase
    {
      
        private readonly IRepoDataAccess ERepository;
        public ExlDataController(IRepoDataAccess _ERepository)
        {
            ERepository = _ERepository;
        }


        //public static Task InjectLiveReloadScriptAsync(
        //    byte[] buffer,
        //    int offset, int count,
        //    HttpContext context,
        //    Stream baseStream)
        //{
        //    Span<byte> currentBuffer = buffer;
        //    var curBuffer = currentBuffer.Slice(offset, count).ToArray();
        //    return InjectLiveReloadScriptAsync(curBuffer, context, baseStream);
        //}
        [HttpGet("{id}")]
        public void Getexcel(int id)
        {
           
            ExcelDataObj model = new ExcelDataObj();
            var dtaobj = ERepository.GetExceldata(id);  //Calling sp using EF Core
                                                         // var dtaobj = ERepository.GetDataById(1);  //Using ado.net 

            string base64data = string.Empty;
            if (dtaobj.excel != null)
            {
                base64data = dtaobj.excel;

                byte[] bytes = Convert.FromBase64String(base64data);

                //////

                /////
                string fileName = dtaobj.excelName;
                var response = new FileContentResult(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                response.FileDownloadName = fileName;

                Response.Clear();
                Response.Headers.Add("content-disposition", "attachment; filename=" + fileName);
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.Body.WriteAsync(bytes);
                // Response.OutputStream.Write(bytes, 0, bytes.Length);
                //  Response.StatusCode = StatusCodes.Status200OK;

                // Response.End();

            }
            //  return base64data;
        }
        [HttpGet]
        public IEnumerable<ExcelDataObj> Getexcel()
        {
            List<ExcelDataObj> objlst = new List<ExcelDataObj>(); 
             ExcelDataObj model = new ExcelDataObj();  
           objlst =  ERepository.GetReportList();  
             return objlst;
        }


        private ExcelDataObj PopulateModel(ExcelDataObj model, IDictionary values)
        {
            model.id = Convert.ToInt32(values["id"]);
            model.excelName = Convert.ToString(values["excelName"]);
            model.excel= Convert.ToString(values["excel"]);
            return model;
        }
            [HttpPost]
        public string Post(ExcelDataObj values) //, bool includeAddress = false
        {
            ExcelDataObj model = new ExcelDataObj();
          //  var valuesDict = JsonConvert.DeserializeObject<IDictionary>(values);
         //   model = PopulateModel(model, valuesDict);

            string status = "";
            //Int32 rslt = ERepository.UpdateExcelData(values);
            status = ERepository.UpdateData(values);
                
         
            return status;
        }

    }
}
