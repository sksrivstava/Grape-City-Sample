import './app.css';
import 'bootstrap.css';
import '@grapecity/wijmo.styles/wijmo.css';
//

import * as React from 'react';
import * as ReactDOM from 'react-dom';
import * as wijmo from '@grapecity/wijmo';
import * as wjGridSheet from "@grapecity/wijmo.react.grid.sheet";
import * as wjInput from '@grapecity/wijmo.react.input';

class App extends React.Component {
    constructor(props) {
        super(props);
        this._applyFillColor = false;
        //
        this._fonts = [
            { name: 'Arial', value: 'Arial, Helvetica, sans-serif' },
            { name: 'Arial Black', value: '"Arial Black", Gadget, sans-serif' },
            { name: 'Comic Sans MS', value: '"Comic Sans MS", cursive, sans-serif' },
            { name: 'Courier New', value: '"Courier New", Courier, monospace' },
            { name: 'Georgia', value: 'Georgia, serif' },
            { name: 'Impact', value: 'Impact, Charcoal, sans-serif' },
            { name: 'Lucida Console', value: '"Lucida Console", Monaco, monospace' },
            { name: 'Lucida Sans Unicode', value: '"Lucida Sans Unicode", "Lucida Grande", sans-serif' },
            { name: 'Palatino Linotype', value: '"Palatino Linotype", "Book Antiqua", Palatino, serif' },
            { name: 'Tahoma', value: 'Tahoma, Geneva, sans-serif' },
            { name: 'Segoe UI', value: '"Segoe UI", "Roboto", sans-serif' },
            { name: 'Times New Roman', value: '"Times New Roman", Times, serif' },
            { name: 'Trebuchet MS', value: '"Trebuchet MS", Helvetica, sans-serif' },
            { name: 'Verdana', value: 'Verdana, Geneva, sans-serif' }
        ];
        //
        this._fontSizeList = [
            { name: '8', value: '8px' },
            { name: '9', value: '9px' },
            { name: '10', value: '10px' },
            { name: '11', value: '11px' },
            { name: '12', value: '12px' },
            { name: '14', value: '14px' },
            { name: '16', value: '16px' },
            { name: '18', value: '18px' },
            { name: '20', value: '20px' },
            { name: '22', value: '22px' },
            { name: '24', value: '24px' }
        ];
        this._updatingSelection = false;
        //

        // merge cell
        this.mergeCells = () => {
            this.state.flex.mergeRange();
            this.setState(this.state.flex.getSelectionFormatState());
        };
        //merge block end

        this.state = {
            selectedValue: '0',
            fontIdx: 0,
            fontSizeIdx: 5,
            isBold: false,
            isItalic: false,
            isUnderline: false,
            textAlign: 'left',
            fileName: "",
            flex: null,
            blob: null
        };
    }

    Convt_html = () => {
        debugger;
        const element = document.createElement("a");
        var file = document.getElementById('Grid_Cont').innerHTML;

        //var file = document.getElementsByClassName('wj-cells'); //.innerHTML;  //wj - cells').innerHTML;
        
        //var file = new Blob([document.getElementById('Grid_Cont').innerHTML], { type: 'text/plain' });
        console.log(file);

        var htmlstr = '<!DOCTYPE html> <html lang="en">';
        htmlstr = htmlstr + '<head><meta charset="utf-8">';
        htmlstr = htmlstr + '<meta http-equiv="X-UA-Compatible" content="IE=edge">';
        htmlstr = htmlstr + '<link type="text/css" rel="stylesheet" href="http://localhost:3019/node_modules/bootstrap/dist/css/bootstrap.min.css" data-systemjs-css="">';
        htmlstr = htmlstr + '<link type="text/css" rel="stylesheet" href="http://localhost:3019/node_modules/@grapecity/wijmo.styles/wijmo.css" data-systemjs-css="">';
        htmlstr = htmlstr + '<style> .container-fluid .wj-flexsheet {height: 400px;margin: 6px 0;}';
        htmlstr = htmlstr + '</style></head><body>";';
        htmlstr = htmlstr + file;
        htmlstr = htmlstr + '</body>';
        console.log(htmlstr);

        debugger;
        var myBlob = new Blob([htmlstr], { type: 'text/html' });
 
        element.href = URL.createObjectURL(myBlob);
        element.download = "myFile.HTML";
        document.body.appendChild(element); // Required for this to work in FireFox
        element.click();
    }
    render() {
        return (<div className="container-fluid" >
            <wjGridSheet.FlexSheet initialized={this.initializeFlexSheet.bind(this)} id="Grid_Cont">
              
            </wjGridSheet.FlexSheet>
            <wjInput.ColorPicker style={{ display: "none", position: "fixed", zIndex: 100 }}
                initialized={this.colorPickerInit.bind(this)}>
            </wjInput.ColorPicker>
            <div className="well well-lg">
                <wjInput.Menu header='Format' value={this.state.selectedValue} itemClicked={this.formatChanged.bind(this)}>
                    <wjInput.MenuItem value="0">Decimal Format</wjInput.MenuItem>
                    <wjInput.MenuItem value="n2">Number Format</wjInput.MenuItem>
                    <wjInput.MenuItem value="p">Percentage Format</wjInput.MenuItem>
                    <wjInput.MenuItem value="c2">Currency Format</wjInput.MenuItem>
                    <wjInput.MenuSeparator></wjInput.MenuSeparator>
                    <wjInput.MenuItem value="d">Short Date</wjInput.MenuItem>
                    <wjInput.MenuItem value="D">Long Date</wjInput.MenuItem>
                    <wjInput.MenuItem value="f">Full Date/TIme (short time)</wjInput.MenuItem>
                    <wjInput.MenuItem value="F">Full Date/TIme (long time)</wjInput.MenuItem>
                </wjInput.Menu>
                <div>Font:
                        <wjInput.ComboBox style={{ width: "120px" }} itemsSource={this._fonts} selectedIndex={this.state.fontIdx} displayMemberPath="name" selectedValuePath="value" isEditable={false} selectedIndexChanged={this.fontChanged.bind(this)}>
                    </wjInput.ComboBox>
                    <wjInput.ComboBox style={{ width: "80px" }} itemsSource={this._fontSizeList} selectedIndex={this.state.fontSizeIdx} displayMemberPath="name" selectedValuePath="value" isEditable={false} selectedIndexChanged={this.fontSizeChanged.bind(this)}>
                    </wjInput.ComboBox>
                    <div className="btn-group">
                        <button type="button" className={`btn btn-default ${this.state.isBold ? 'active' : ''}`} onClick={this.applyBoldStyle.bind(this)}>
                            Bold</button>
                        <button type="button" className={`btn btn-default ${this.state.isItalic ? 'active' : ''}`} onClick={this.applyItalicStyle.bind(this)}>
                            Italic</button>
                        <button type="button" className={`btn btn-default ${this.state.isUnderline ? 'active' : ''}`} onClick={this.applyUnderlineStyle.bind(this)}>
                            Underline</button>
                    </div>
                </div>
                <div>Color:
                        <div className="btn-group">
                        <button type="button" className="btn btn-default" onClick={(e) => this.showColorPicker(e, false)}>
                            Fore Color</button>
                        <button type="button" className="btn btn-default" onClick={(e) => this.showColorPicker(e, true)}>
                            Fill Color</button>
                    </div>Alignment:
                        <div className="btn-group">
                        <button type="button" className={`btn btn-default ${this.state.textAlign == 'left' ? 'active' : ''}`} onClick={() => this.applyCellTextAlign("left")}>
                            Left</button>
                        <button type="button" className={`btn btn-default ${this.state.textAlign == 'center' ? 'active' : ''}`} onClick={() => this.applyCellTextAlign("center")}>
                            Center</button>
                        <button type="button" className={`btn btn-default ${this.state.textAlign == 'right' ? 'active' : ''}`} onClick={() => this.applyCellTextAlign("right")}>
                            Right</button>
                    </div>
                </div>
            </div>
            <div className="form-inline well well-lg">
                <button onClick={this.mergeCells.bind(this)} type="button" className="btn btn-default">
                    {this.state.isMergedCell ? 'UnMerge' : 'Merge'}
                </button>
                <button type="button" className={`btn btn-default`} onClick={() => this.Convt_html()}>
                    Convert To HTML</button>
                <button type="button" className={`btn btn-default`} onClick={() => this.ChangeCellvalue("Sanjeeva")}>
                    Replace Cell Value  </button>
                <button type="button" className={`btn btn-default`} onClick={() => this.ChangeSheet("0")}>
                    Sheet 1 </button>
                <button type="button" className={`btn btn-default`} onClick={() => this.ChangeSheet("1")}>
                     Sheet 2</button>
                <button type="button" className={`btn btn-default`} onClick={() => this.ChangeSheet("2")}>
                     Sheet 3</button>
                <button type="button" className={`btn btn-default`} onClick={() => this.newSheet()}>
                    Add Sheet</button>
                
            </div>
            <div className="form-inline well well-lg">
                

                <input type="file" className="form-control" id="importFile" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" />
                <button className="btn btn-default" onClick={this.load.bind(this)}>Load</button>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                File Name:
                <input type="text" className="form-control" onChange={this.setFileName.bind(this)} value={this.state.fileName} />
                <button className="btn btn-default" onClick={this.save.bind(this)}>Save</button>
            </div>



        </div>);
    }
    initializeFlexSheet(flex) {
        flex.deferUpdate(() => {
            if (flex) {
                fetch('http://localhost:3000/api/open/Sample.xlsx')
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.blob();
                    })
                    .then(myBlob => {
                        this.setState({ fileName: 'Sample.xlsx' })
                        this.setState({ blob: myBlob })
                        this.state.flex.loadAsync(myBlob);
                    })
                    .catch(error => {
                        console.error('There has been a problem with your fetch operation:', error);
                    });

                flex.selectedSheetIndex = 0;

                setTimeout(() => this._updateSelection(flex, flex.selection), 100);
            }
        });

        flex.selectionChanged.addHandler((flex, args) => {
            this._updateSelection(flex, args.range);
        });

        //merge cell
        flex.selectionChanged.addHandler(() => {
            this.setState(flex.getSelectionFormatState());
        });
        //merge cell end

        this.setState({
            flex: flex
        });
    }

    fontChanged(flex) {
        if (flex.selectedItem && !this._updatingSelection) {
            this.state.flex.applyCellsStyle({ fontFamily: flex.selectedItem.value });
        }
    }
    //
    fontSizeChanged(flex) {
        if (flex.selectedItem && !this._updatingSelection) {
            this.state.flex.applyCellsStyle({ fontSize: flex.selectedItem.value });
        }
    }
    //
    colorPickerInit(flex) {
        let blurEvt = /firefox/i.test(window.navigator.userAgent) ? 'blur' : 'focusout';
        flex.hostElement.addEventListener(blurEvt, () => {
            setTimeout(() => {
                if (!flex.containsFocus()) {
                    this._updatingSelection = false;
                    flex.hostElement.style.display = 'none';
                }
            }, 0);
        });
        //
        // Initialize the value changed event handler for the color picker control.
        flex.valueChanged.addHandler(() => {
            if (this._applyFillColor) {
                this.state.flex.applyCellsStyle({ backgroundColor: flex.value });
            }
            else {
                this.state.flex.applyCellsStyle({ color: flex.value });
            }
        });
        //
        this._colorPicker = flex;
    }

    formatChanged(flex) {
        if (flex.selectedValue) {
            this.state.flex.applyCellsStyle({ format: flex.selectedValue });
            this.setState({ selectedValue: flex.selectedValue });
        }
    }
    //
    // apply the text alignment for the selected cells
    applyCellTextAlign(value) {
        debugger;
        this.state.flex.applyCellsStyle({ textAlign: value });
        this.setState({ textAlign: value });
        
    }
    ChangeCellvalue(val) {
        this.state.flex.activeCell.innerHTML = val;
    }
    ChangeSheet(value) {
        //this.ChangeSheet("Sheet1"); // = 0;
        debugger;
        this.state.flex.selectedSheetIndex = value;
        //FlexSheet.selectedSheet = "Sheet1";
        //this.setState({ selectedSheet: "Sheet1" });
    }
    newSheet() {
        //this.ChangeSheet("Sheet1"); // = 0;
        debugger;
        this.state.flex.sheets.insert(4, "");
            //.FlexSheet.append("sheet4", "", Sample);
       // this.state.flex.appendChild()
        //FlexSheet.selectedSheet = "Sheet1";
        //this.setState({ selectedSheet: "Sheet1" });
    }
    //
    // apply the bold font weight for the selected cells
    applyBoldStyle() {
        this.state.flex.applyCellsStyle({ fontWeight: this.state.isBold ? 'none' : 'bold' });
        this.setState({ isBold: !this.state.isBold });
    }
    //
    // apply the underline text decoration for the selected cells
    applyUnderlineStyle() {
        this.state.flex.applyCellsStyle({ textDecoration: this.state.isUnderline ? 'none' : 'underline' });
        this.setState({ isUnderline: !this.state.isUnderline });
    }
    //
    // apply the italic font style for the selected cells
    applyItalicStyle() {
        this.state.flex.applyCellsStyle({ fontStyle: this.state.isItalic ? 'none' : 'italic' });
        this.setState({ isItalic: !this.state.isItalic });
    }
    //
    // show the color picker control.
    showColorPicker(e, isFillColor) {
        let offset = this._cumulativeOffset(e.target);
        //
        let he = this._colorPicker.hostElement;
        he.style.display = 'inline';
        he.style.left = offset.left + 'px';
        he.style.top = offset.top - he.clientHeight - 5 + 'px';
        he.focus();
        //
        this._applyFillColor = isFillColor;
    }

    _updateSelection(fs, sel) {
        let rCnt = fs.rows.length, cCnt = fs.columns.length, fontIdx = 0, fontSizeIdx = 5;
        //
        this._updatingSelection = true;
        //
        if (sel.row > -1 && sel.col > -1 && rCnt > 0 && cCnt > 0 && sel.col < cCnt && sel.col2 < cCnt && sel.row < rCnt && sel.row2 < rCnt) {
            let cellContent = fs.getCellData(sel.row, sel.col, false), cellStyle = fs.selectedSheet.getCellStyle(sel.row, sel.col), cellFormat;
            //
            if (cellStyle) {
                fontIdx = this._checkFontfamily(cellStyle.fontFamily);
                fontSizeIdx = this._checkFontSize(cellStyle.fontSize);
                cellFormat = cellStyle.format;
            }
            //
            let format;
            if (!!cellFormat) {
                format = cellFormat;
            }
            else {
                if (wijmo.isInt(cellContent)) {
                    format = '0';
                }
                else if (wijmo.isNumber(cellContent)) {
                    format = 'n2';
                }
                else if (wijmo.isDate(cellContent)) {
                    format = 'd';
                }
            }
            //
            let state = fs.getSelectionFormatState();
            this.setState({
                isBold: state.isBold,
                isItalic: state.isItalic,
                isUnderline: state.isUnderline,
                textAlign: state.textAlign,
                fontIdx: fontIdx,
                fontSizeIdx: fontSizeIdx
            });
        }
        //
        this._updatingSelection = false;
    }

    // check font family for the font name combobox of the ribbon.
    _checkFontfamily(value) {
        let fonts = this._fonts;
        //
        if (!value) {
            return 0;
        }
        //
        for (let fontIndex = 0; fontIndex < fonts.length; fontIndex++) {
            let font = fonts[fontIndex];
            if (font.name === value || font.value === value) {
                return fontIndex;
            }
        }
        //
        return 0;
    }
    //
    // check font size for the font size combobox of the ribbon.
    _checkFontSize(value) {
        let sizeList = this._fontSizeList;
        //
        if (value == null) {
            return 5;
        }
        //
        for (let index = 0; index < sizeList.length; index++) {
            let size = sizeList[index];
            if (size.value === value || size.name === value) {
                return index;
            }
        }
        //
        return 5;
    }
    //
    // Get the absolute position of the dom element.
    _cumulativeOffset(element) {
        let top = 0, left = 0, scrollTop = 0, scrollLeft = 0;
        //
        do {
            top += element.offsetTop || 0;
            left += element.offsetLeft || 0;
            scrollTop += element.scrollTop || 0;
            scrollLeft += element.scrollLeft || 0;
            element = element.offsetParent;
        } while (element && !(element instanceof HTMLBodyElement));
        //
        scrollTop += document.body.scrollTop || document.documentElement.scrollTop;
        scrollLeft += document.body.scrollLeft || document.documentElement.scrollLeft;
        //
        return {
            top: top - scrollTop,
            left: left - scrollLeft
        };
    }

    // Load xlsx file to FlexSheet.
    load() {
        let fileInput = document.getElementById("importFile");

        if (this.state.flex && fileInput.files[0]) {
            this.state.flex.loadAsync(fileInput.files[0]);
        }
    }
    // Save FlexSheet to xlsx file.
    save() {
        let fileName;
        if (!!this.state.fileName) {
            fileName = this.state.fileName;
        }
        else {
            fileName = "FlexSheet.xlsx";
        }

        const url = "http://localhost:3000/api/save";
        const data = new FormData()
        data.append("file", this.state.flex)
        fetch(url, {
            method: 'POST',
            mode: 'cors',
            headers: {
                "Content-type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            },
            referrerPolicy: 'no-referrer',
            body: {
                xlfile: data //this.state.blob //this.state.flex
            }
        }).then(response => {
            console.warn(response);
        })
            .catch(error => {
                console.error('There has been a problem with your fetch operation:', error);
            });

        //console.warn(this.state.flex);

        //this.state.flex.saveAsync(fileName);
    }

    setFileName(name) {
        this.setState({
            fileName: name.target.value
        });
    }
}
ReactDOM.render(<App />, document.getElementById('app'));
